<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        .main{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    </style>
</head>
<body>
  <div class="main">
  <h1>Admin Dashboard</h1><br>
  <a href="./additem.php">Add Items</a>
  <a href="./addcategory.php">Add Categories</a>
  </div>

</body>
</html>